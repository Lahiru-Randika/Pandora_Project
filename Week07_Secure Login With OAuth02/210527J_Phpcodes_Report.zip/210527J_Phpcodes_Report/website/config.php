<?php
return [
    'client_id' => '28710588768-pm6hamc29hf3vduuj06k3299eprngcbm.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri' => 'http://localhost/website/redirect.php'
];
